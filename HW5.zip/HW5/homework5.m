clc
clear all
A=[1 1 ; 0 2]
B=[0;1]
Q=[1 0; 0 1]
R=1
[P,L,K]=care(A,B,Q)
x0=[1;1]
t=0:0.1:10
u=zeros(size(t))
[y,x]=lsim(A-B*K, [0;0], [1 0],0,u,t,x0)
plot(t,x)