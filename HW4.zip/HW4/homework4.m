clc;
clear all;
a = [-1 -.016; 1 0];
b = [1;0];
c = eye(2);
d = 0;
x0 = [0;1];
N_length = 10;
x = zeros(2,N_length)
y = zeros(2,N_length)
x(:,1) = x0;
y(:,1) = c*x(:,1);
for k = 2:10
   x(:,k) = a*x(:,k-1);
   y(:,k) = c*x(:,k-1);
end
figure(1);
stem(1:1:10,y(1:1:10));
figure(2);
stem(1:1:10,y(2:1:10));
grid;